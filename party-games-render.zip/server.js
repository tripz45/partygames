const http=require('http'),fs=require('fs'),path=require('path');
http.createServer((q,r)=>{fs.readFile(path.join(__dirname,'index.html'),(e,d)=>{r.writeHead(e?500:200,{'Content-Type':'text/html; charset=utf-8'});r.end(e?'Error':d)})}).listen(process.env.PORT||3000);
